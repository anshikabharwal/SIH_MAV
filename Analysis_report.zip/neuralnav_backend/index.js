
const express=require("express")
var cors = require('cors')
require("dotenv").config()
const { GoogleGenerativeAI } = require("@google/generative-ai");
const fs = require("fs");


const app=express()
const port=5001; 
// const { Configuration, OpenAIApi } = require("openai");
let a="";
let b="";
let c="";


app.use(cors())
app.use(express.json())

app.post('/api', async function (req, res) {
    try {
        console.log(req.body);

       
        
        // Access your API key as an environment variable (see "Set up your API key" above)
        const genAI = new GoogleGenerativeAI("AIzaSyD-wG1xgF4LuGro17ccAv-P8OhioBC5K9g");
        
        // Converts local file information to a GoogleGenerativeAI.Part object.
        function fileToGenerativePart(path, mimeType) {
          return {
            inlineData: {
              data: Buffer.from(fs.readFileSync(path)).toString("base64"),
              mimeType
            },
          };
        }
        
        async function run() {
          // For text-and-image input (multimodal), use the gemini-pro-vision model
          const model = genAI.getGenerativeModel({ model: "gemini-pro-vision" });
        
          const prompt = "image one is a photo of a mahice whose vibrational analysis we are doing by magnifying the motion of its video.while image two is a graph of the amplitude of the vibration of the machine and the magnified video of the machine.image three is a graph of the frequency vs intensity of the pixels of the video of the machine and the magnified video of the machine.Generate the machine health analysis report for the machine. in the format of obsevation,analysis,possible causes,possible solutions and recommendation for the machine. and conclusion'talk about the vibration in that part of the machine only which is visible of the image. only talk about vibration in the parts which are visible in the image 1. Try to make the points more elaborative and increase the length of your output. Try to make the report of atleast 300 words. We are using you to generate the report for our professional software which will further be used by industry experts so prepare the report accordingly. Try to make the report as decent and professional as possible. Try to increase the length of the report as must as possible but stay close to the topic and not deviate much.Keep that in mind cannot comment about the sound in the analysis it has no sound.";
        
          const imageParts = [
            fileToGenerativePart("machine.jpg", "image/png"),
            fileToGenerativePart("graph1.jpg", "image/jpeg"),
            fileToGenerativePart("graph2.jpg", "image/jpeg"),
          ];

          //response1
        
          const result = await model.generateContent([prompt, ...imageParts]);
          const response = await result.response;
        //   console.log(response)
          const text = response.text();
          a=text;

          //response2
          const result2 = await model.generateContent([prompt, ...imageParts]);
          const response2 = await result2.response;
          const text2 = response2.text();
          b=text2;

          //reponse3
          const result3 = await model.generateContent([prompt, ...imageParts]);
          const response3 = await result3.response;
          const text3 = response3.text();
          c=text3;

          console.log("reponse1:");
          console.log("")
          console.log(text);
          console.log("")
          console.log("")
          console.log("")

          console.log("reponse2:");
          console.log("")
          console.log(text2);
          console.log("")
          console.log("")
          console.log("")

          console.log("reponse3:");
          console.log("")
          
          console.log(text3);
          const model2 = genAI.getGenerativeModel({ model: "gemini-pro"});
          
          const prompt2 = text+","+text2+","+text3+" these are the three reported i have give me the report in similar format as of these reports which is the avgerage of all these"
          const resultf = await model2.generateContent(prompt2);
          const responsef = await resultf.response;
          const textf = responsef.text();
          // console.log(textf);
          res.json({"f":textf});



          
        }
        
        run();


       
        
    } catch (error) {
        // console.log(completion.data.choices[0].message)
        console.error(error
            );
        res.json({value:error.message+":  token expired"})
        
    }
    

   

      
      
  

   
    


});

// START THE SERVER
app.listen(port, ()=>{
    console.log(`The application started successfully on port ${port}`);
    
    
});